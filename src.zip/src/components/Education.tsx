import React from 'react';
import { Check, GraduationCap, Leaf, School } from 'lucide-react';

type EducationCardProps = {
  index: string;
  label: string;
  title: string;
  description: string;
  tags: string[];
  icon: typeof GraduationCap;
  featured?: boolean;
  gridClassName: string;
};

const EducationCard: React.FC<EducationCardProps> = ({
  index,
  label,
  title,
  description,
  tags,
  icon: Icon,
  featured = false,
  gridClassName,
}) => (
  <article
    className={`group relative flex min-h-[290px] flex-col overflow-hidden rounded-3xl border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl sm:p-8 ${gridClassName} ${
      featured
        ? 'border-emerald-200 bg-emerald-50/80 shadow-lg shadow-emerald-950/5 hover:border-emerald-300 hover:shadow-emerald-950/10'
        : 'border-green-100 bg-green-50/55 shadow-lg shadow-green-950/[0.03] hover:border-green-200 hover:shadow-green-950/[0.08]'
    }`}
  >
    <span className="pointer-events-none absolute -right-1 -top-5 select-none text-8xl font-black tracking-tighter text-emerald-900/[0.055] transition-transform duration-500 group-hover:scale-110">
      {index}
    </span>

    <div className="relative flex items-start justify-between gap-4">
      <span className={`flex h-12 w-12 items-center justify-center rounded-2xl border ${featured ? 'border-emerald-200 bg-white text-emerald-700' : 'border-green-200 bg-white/80 text-green-700'}`}>
        <Icon className="h-6 w-6" strokeWidth={1.8} />
      </span>
      <span className="font-mono text-xs font-bold tracking-wider text-emerald-700/50">{index}</span>
    </div>

    <div className="relative mt-7">
      <p className="text-xs font-bold tracking-[0.14em] text-emerald-700">{label}</p>
      <h3 className="mt-2 text-2xl font-bold tracking-tight text-emerald-950">{title}</h3>
      <p className="mt-3 max-w-xl text-sm leading-6 text-emerald-950/65">{description}</p>
    </div>

    <div className="relative mt-auto flex items-center gap-2 pt-7">
      {tags.map((tag) => (
        <span key={tag} className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-emerald-200/80 bg-white/80 px-2.5 py-1.5 text-xs font-semibold text-emerald-900 shadow-sm">
          <Check className="h-3.5 w-3.5 text-emerald-600" strokeWidth={2.5} />
          {tag}
        </span>
      ))}
    </div>
  </article>
);

export const Education: React.FC = () => (
  <section id="education" className="border-t border-emerald-100 bg-[#fcfffd] py-16 dark:border-emerald-950 dark:bg-slate-950 sm:py-20">
    <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
      <div className="mb-10 flex flex-col justify-between gap-5 sm:mb-12 sm:flex-row sm:items-end">
        <div>
          <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-bold tracking-[0.14em] text-emerald-700">
            <Leaf className="h-3.5 w-3.5" strokeWidth={2} />
            EDUCATION
          </p>
          <h2 className="text-3xl font-bold tracking-[-0.035em] text-emerald-950 sm:text-4xl">Academic background</h2>
        </div>
        <p className="max-w-md text-sm leading-6 text-emerald-950/60">A solid academic base that supports thoughtful technical work and continuous growth.</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-12">
        <EducationCard
          featured
          gridClassName="lg:col-span-7"
          index="01"
          icon={GraduationCap}
          label="HIGHER EDUCATION"
          title="University Diploma"
          description="University-level study focused on building a strong foundation in technology, problem-solving, and professional practice."
          tags={['Academic credential', 'Technology foundation']}
        />
        <EducationCard
          index="02"
          gridClassName="lg:col-span-5"
          icon={School}
          label="SECONDARY EDUCATION"
          title="High School Diploma"
          description="Completed secondary education with the core academic foundation for continued study and lifelong learning."
          tags={['Secondary credential', 'Academic foundation']}
        />
      </div>
    </div>
  </section>
);
