import React, { useState } from 'react';
import { Experience as ExperienceType, DeveloperProfile } from '../types';
import {
  Briefcase,
  Calendar,
  MapPin,
  CheckCircle2,
  FileText,
  Download,
  Printer,
  X,
  Building2,
  Sparkles,
  Copy,
  Check
} from 'lucide-react';

interface ExperienceProps {
  experiences: ExperienceType[];
  profile: DeveloperProfile;
}

export const Experience: React.FC<ExperienceProps> = ({ experiences, profile }) => {
  const [showResumeModal, setShowResumeModal] = useState(false);
  const [copiedResume, setCopiedResume] = useState(false);

  const handlePrintResume = () => {
    window.print();
  };

  const handleCopyResumeText = () => {
    const text = `
${profile.name} - ${profile.title}
Location: ${profile.location} | Email: ${profile.email} | GitHub: ${profile.github}

SUMMARY:
${profile.resumeSummary}

EXPERIENCE:
${experiences
  .map(
    (e) => `
${e.role} @ ${e.company} (${e.period})
Location: ${e.location} | Type: ${e.type}
${e.summary}
Key Achievements:
${e.achievements.map((a) => `- ${a}`).join('\n')}
Tech Stack: ${e.techStack.join(', ')}
`
  )
  .join('\n')}
`;
    navigator.clipboard.writeText(text);
    setCopiedResume(true);
    setTimeout(() => setCopiedResume(false), 2000);
  };

  return (
    <section id="experience" className="min-h-screen flex flex-col justify-center py-16 sm:py-20 bg-slate-50/70 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800/80 relative transition-colors">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 lg:px-8 w-full">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800 shadow-2xs">
              <Briefcase className="w-3.5 h-3.5" />
              Professional Career Track
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white tracking-tight">
              Work Experience & Impact History
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              5+ years building and scaling enterprise MERN stack web applications, leading engineering initiatives, and optimizing cloud database performance.
            </p>
          </div>

          <button
            onClick={() => setShowResumeModal(true)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-500 text-white font-medium text-xs transition-all shadow-sm active:scale-95 shrink-0 cursor-pointer"
          >
            <FileText className="w-4 h-4 text-white" />
            <span>View Formatted Resume</span>
          </button>
        </div>

        {/* Timeline Stack */}
        <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-4 lg:ml-8 space-y-12">
          {experiences.map((exp) => (
            <div key={exp.id} className="relative pl-8 group">
              
              {/* Timeline Dot */}
              <div className="absolute -left-[9px] top-1.5 w-4 h-4 rounded-full bg-white dark:bg-slate-900 border-2 border-slate-900 dark:border-blue-400 group-hover:scale-125 transition-transform shadow-2xs" />

              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all space-y-4">
                
                {/* Header info */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <span>{exp.role}</span>
                      <span className="text-blue-700 dark:text-blue-400 font-semibold font-mono text-sm">@ {exp.company}</span>
                    </h3>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-1">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                        {exp.location}
                      </span>
                      <span>•</span>
                      <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium">
                        {exp.type}
                      </span>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shrink-0">
                    <Calendar className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    {exp.period}
                  </span>
                </div>

                {/* Summary */}
                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-sans">
                  {exp.summary}
                </p>

                {/* Key Achievements Bullet points */}
                <div className="space-y-2">
                  <div className="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 font-semibold">
                    Key Architectural & Engineering Contributions:
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {exp.achievements.map((ach, i) => (
                      <div key={i} className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
                        <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                        <span className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">{ach}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tech Stack Pills */}
                <div className="flex flex-wrap gap-1.5 pt-2">
                  {exp.techStack.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Formatted Resume Modal */}
      {showResumeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col text-slate-900 dark:text-white">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-10">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-slate-900 dark:text-white" />
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  Formatted Developer Resume - {profile.name}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyResumeText}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 cursor-pointer"
                >
                  {copiedResume ? <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedResume ? 'Copied' : 'Copy Text'}</span>
                </button>
                <button
                  onClick={handlePrintResume}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-500 text-white text-xs font-medium shadow-2xs cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print / Save PDF</span>
                </button>
                <button
                  onClick={() => setShowResumeModal(false)}
                  className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Content */}
            <div className="p-8 space-y-6 overflow-y-auto font-sans bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-800 m-4 rounded-xl">
              <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{profile.name}</h1>
                <p className="text-sm font-semibold text-blue-700 dark:text-blue-400 font-mono">{profile.title}</p>
                <div className="flex flex-wrap gap-4 text-xs text-slate-500 dark:text-slate-400 font-mono mt-2">
                  <span>📍 {profile.location}</span>
                  <span>📧 {profile.email}</span>
                  <span>🔗 {profile.github}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  EXECUTIVE SUMMARY
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {profile.resumeSummary}
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  PROFESSIONAL EXPERIENCE
                </h3>
                {experiences.map((exp) => (
                  <div key={exp.id} className="space-y-1.5">
                    <div className="flex justify-between items-baseline">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {exp.role} — <span className="text-blue-700 dark:text-blue-400">{exp.company}</span>
                      </h4>
                      <span className="text-xs font-mono text-slate-500 dark:text-slate-400">{exp.period}</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">{exp.summary}</p>
                    <ul className="list-disc list-inside text-xs text-slate-600 dark:text-slate-300 space-y-1">
                      {exp.achievements.map((ach, idx) => (
                        <li key={idx}>{ach}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  TECHNICAL SKILLS
                </h3>
                <p className="text-xs font-mono text-slate-800 dark:text-slate-200">
                  {profile.topSkills.join(' • ')}
                </p>
              </div>
            </div>

          </div>
        </div>
      )}
    </section>
  );
};
